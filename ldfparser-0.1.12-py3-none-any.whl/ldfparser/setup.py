from setuptools import setup

setup(
    name="ldfparser",
    version="0.1.12",
    packages=["ldfparser"],
    package_dir={"ldfparser": "."},  # Указываем, что пакет находится в текущей папке
    package_data={"ldfparser": ["*.py", "grammars/*", "templates/*"]},
    include_package_data=True,
)